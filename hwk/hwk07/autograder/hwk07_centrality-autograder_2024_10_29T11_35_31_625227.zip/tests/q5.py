OK_FORMAT = True

test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> np.isclose(np.average(moc_data['betweenness_centrality']), 0.0012489557440977927)\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(np.average(moc_data['eigenvector_centrality']), 0.04087718891140618)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
