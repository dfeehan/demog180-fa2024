OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> bc_node3 == 2\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> bc_node5 == 2\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
