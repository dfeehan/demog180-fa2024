OK_FORMAT = True

test = {   'name': 'q6',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> round(abs_log(0.2021),3) == 1.599\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
