OK_FORMAT = True

test = {'name': 'q1', 'points': 1, 'suites': [{'cases': [{'code': '>>> round(q1,1) == 2022.0\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
