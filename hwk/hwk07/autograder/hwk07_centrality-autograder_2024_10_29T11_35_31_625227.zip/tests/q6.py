OK_FORMAT = True

test = {   'name': 'q6',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> np.isclose(len(party_degree), 2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(np.average(party_degree['degree mean']), 170.62777118876014)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
