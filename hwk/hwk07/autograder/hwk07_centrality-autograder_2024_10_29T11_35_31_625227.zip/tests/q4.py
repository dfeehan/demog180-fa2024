OK_FORMAT = True

test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> np.isclose(np.average(moc_node_centrality_dat['degree']), 184.03853564547205)\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(np.average(moc_node_centrality_dat['betweenness_centrality']), 0.0012489557440977924)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
