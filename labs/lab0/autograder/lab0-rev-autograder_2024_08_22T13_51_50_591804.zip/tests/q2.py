OK_FORMAT = True

test = {'name': 'q2', 'points': 1, 'suites': [{'cases': [{'code': '>>> round(q2,3) == 0.440\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
