OK_FORMAT = True

test = {   'name': 'q8',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> round(sd(make_array(2,4,6,8,10)),3) == 2.828\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
