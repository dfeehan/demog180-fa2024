OK_FORMAT = True

test = {   'name': 'q17',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> np.isclose(len(sim_results_aggregate), 5)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(sum(sim_results_aggregate['num_vaccines']), 1800)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
