OK_FORMAT = True

test = {   'name': 'q15',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> np.isclose(moc_sir_mean_infected, 296.7436666666667)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
