OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> test_bc == {1: 0.0, 2: 2.0, 3: 2.0, 4: 0.0, 5: 2.0, 6: 2.0}\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
