OK_FORMAT = True

test = {   'name': 'q4',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> round(near_twenty,3) == 19.999\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
