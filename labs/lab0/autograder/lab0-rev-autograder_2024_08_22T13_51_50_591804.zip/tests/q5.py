OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> round(sine_of_pi_over_four,3) == 0.707\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
