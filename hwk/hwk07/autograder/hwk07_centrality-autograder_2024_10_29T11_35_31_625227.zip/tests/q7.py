OK_FORMAT = True

test = {   'name': 'q7',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> np.isclose(len(gender_degree), 2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(np.average(gender_degree['degree mean']), 188.98222912353347)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
