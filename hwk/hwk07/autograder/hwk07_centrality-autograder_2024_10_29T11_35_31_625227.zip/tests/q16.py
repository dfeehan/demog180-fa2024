OK_FORMAT = True

test = {   'name': 'q16',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> np.isclose(len(sim_results), 5)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(np.average(sim_results['num_vaccines']), 225)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
